package com.cdac.main;

import BankTest.BankTest;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankTest bank = new BankTest();
		bank.start();
		
	}

}
