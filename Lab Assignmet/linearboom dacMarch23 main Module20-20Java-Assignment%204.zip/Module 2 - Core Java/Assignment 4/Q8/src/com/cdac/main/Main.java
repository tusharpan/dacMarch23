package com.cdac.main;

import university.test.HospitalTest;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HospitalTest test = new HospitalTest();
		test.start();
		
	}

}
