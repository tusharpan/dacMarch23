package com.cdac.main;

import com.cdac.domain.Library;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Library lib = new Library();
		lib.start();
		lib.ScanClose();
	}

}
