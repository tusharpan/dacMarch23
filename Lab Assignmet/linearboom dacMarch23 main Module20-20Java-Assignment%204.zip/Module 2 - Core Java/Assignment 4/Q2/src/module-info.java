/**
 * 
 */
/**
 * @author Dell
 *
 */
module Q2 {
}