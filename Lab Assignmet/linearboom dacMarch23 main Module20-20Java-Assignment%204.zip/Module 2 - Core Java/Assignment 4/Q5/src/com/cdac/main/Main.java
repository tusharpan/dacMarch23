package com.cdac.main;

import com.cdac.util.SportsComplex;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Code is incomplete
		SportsComplex complex = new SportsComplex();
		complex.start();
	}

}
