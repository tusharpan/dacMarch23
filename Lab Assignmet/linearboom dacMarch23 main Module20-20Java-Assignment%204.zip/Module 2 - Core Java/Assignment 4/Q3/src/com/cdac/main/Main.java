package com.cdac.main;

import com.cdac.domain.Payroll;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Payroll pay = new Payroll();
		pay.showPay();
		pay.showFullTime();
	}

}
