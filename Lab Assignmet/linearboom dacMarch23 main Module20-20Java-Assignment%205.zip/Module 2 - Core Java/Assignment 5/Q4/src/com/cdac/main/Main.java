package com.cdac.main;

import com.cdac.test.MenuItem;

public class Main {
	public static void main(String [] args) {
		MenuItem test = new MenuItem();
		test.start();
	}
}
