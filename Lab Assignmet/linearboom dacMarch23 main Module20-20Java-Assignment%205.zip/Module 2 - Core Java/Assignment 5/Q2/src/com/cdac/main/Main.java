package com.cdac.main;

import com.cdac.lib.Library;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Library lib = new Library();
		lib.print();
		lib.sortBooks();
		System.out.println("");
		lib.print();
	}

}
